-- phpMyAdmin SQL Dump
-- version 3.3.0
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 07, 2014 at 04:11 PM
-- Server version: 5.5.40
-- PHP Version: 5.5.9-1ubuntu4.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nhandan`
--

-- --------------------------------------------------------

--
-- Table structure for table `thnd_category`
--

CREATE TABLE IF NOT EXISTS `thnd_category` (
  `categoryid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `module` text NOT NULL,
  `parentid` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `created_date` text NOT NULL,
  `modified_date` text NOT NULL,
  `created_user` int(11) DEFAULT NULL,
  `modified_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`categoryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `thnd_category`
--

INSERT INTO `thnd_category` (`categoryid`, `name`, `module`, `parentid`, `status`, `created_date`, `modified_date`, `created_user`, `modified_user`) VALUES
(1, 'Home', 'project', 0, 1, '', '1417861306', NULL, 1),
(2, 'come back home', 'project', 1, 1, '1417848789', '1417861291', NULL, 1),
(3, 'Name readable', 'project', 0, 1, '', '1417861473', NULL, 1),
(5, 'child', 'project', 2, 1, '1417853378', '', NULL, NULL),
(6, 'neighbor1', 'news', 0, 1, '', '', NULL, NULL),
(7, 'neighbor 2', 'news', 0, 1, '', '', NULL, NULL),
(8, 'childn1', 'news', 6, 1, '1417853676', '', 1, NULL),
(9, 'childn2', 'news', 7, 1, '1417853688', '', 1, NULL),
(10, 'ctest', 'project', 2, 1, '1417853852', '', 1, NULL),
(11, 'tét2', 'project', 1, 1, '1417853927', '', 1, NULL),
(13, 'ctest2', 'project', 11, 1, '1417855129', '', 1, NULL),
(15, 'This is child of ctest', 'project', 10, 1, '1417860633', '1417861275', 1, 1),
(16, 'Child of name', 'project', 3, 1, '1417861507', '', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `thnd_config`
--

CREATE TABLE IF NOT EXISTS `thnd_config` (
  `configid` int(11) NOT NULL AUTO_INCREMENT,
  `modulename` varchar(30) NOT NULL,
  `configname` varchar(30) NOT NULL,
  `configvalue` text NOT NULL,
  `title` text,
  `description` text,
  `created_date` text NOT NULL,
  `modified_date` text NOT NULL,
  `created_user` int(11) DEFAULT NULL,
  `modified_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`configid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `thnd_config`
--

INSERT INTO `thnd_config` (`configid`, `modulename`, `configname`, `configvalue`, `title`, `description`, `created_date`, `modified_date`, `created_user`, `modified_user`) VALUES
(1, 'core', 'siteTitle', 'Trường học nhân dân', 'Site title', NULL, '1414872294', '1415093962', NULL, 1),
(2, 'core', 'logo', 'http://dotank.org.vn/wp-content/uploads/2014/08/chandung.jpg', 'Logo', NULL, '1414872294', '1415093962', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `thnd_log`
--

CREATE TABLE IF NOT EXISTS `thnd_log` (
  `logid` int(11) NOT NULL AUTO_INCREMENT,
  `modulename` varchar(30) NOT NULL,
  `action` varchar(30) NOT NULL,
  `userid` int(11) NOT NULL,
  `description` text,
  PRIMARY KEY (`logid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `thnd_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `thnd_modules`
--

CREATE TABLE IF NOT EXISTS `thnd_modules` (
  `moduleid` int(11) NOT NULL AUTO_INCREMENT,
  `modulename` varchar(30) NOT NULL,
  `moduleroute` text NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` text NOT NULL,
  `modified_date` text NOT NULL,
  `created_user` int(11) DEFAULT NULL,
  `modified_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`moduleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `thnd_modules`
--


-- --------------------------------------------------------

--
-- Table structure for table `thnd_project`
--

CREATE TABLE IF NOT EXISTS `thnd_project` (
  `projectid` int(11) NOT NULL AUTO_INCREMENT,
  `categoryid` int(11) NOT NULL,
  `projectname` text NOT NULL,
  `title` text NOT NULL,
  `imgthumb` text,
  `sapo` text,
  `content` text NOT NULL,
  `deadline` text NOT NULL,
  `goal` double DEFAULT '0',
  `location` text,
  `status` int(11) NOT NULL,
  `created_date` text NOT NULL,
  `modified_date` text NOT NULL,
  `created_user` int(11) DEFAULT NULL,
  `modified_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`projectid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `thnd_project`
--

INSERT INTO `thnd_project` (`projectid`, `categoryid`, `projectname`, `title`, `imgthumb`, `sapo`, `content`, `deadline`, `goal`, `location`, `status`, `created_date`, `modified_date`, `created_user`, `modified_user`) VALUES
(4, 0, 'fsad', 'fas4', 'media/1/project/e2133bb347664be702ebed1138b39603.jpg', '312321312', '<div class="title_news">\n<h1>Nguyễn Cao Kỳ Duyên đăng quang Hoa hậu Việt Nam 2014;</h1>\n</div>\n<div class="short_intro txt_666;">Người đẹp 18; tuổi đến từ Nam Định giành vương miện trong đêm chung kết diễn ra tối 6/12; tại Phú Quốc, Kiên Giang. Danh hiệu Á hậu 1 thuộc về Nguyễn Trần Huyền My. Á hậu 2 là Nguyễn Lâm Diễm Trang.</div>\n<div class="relative_new">\n<ul class="list_news_dot_3x3_300;">\n<li><a title="10; người đẹp nổi bật của cuộc thi Hoa hậu Việt Nam" href="http://giaitri.vnexpress.net/photo/trong-nuoc/10;-nguoi-dep-noi-bat-cua-cuoc-thi-hoa-hau-viet-nam-3116446;.html">10; người đẹp nổi bật của cuộc thi Hoa hậu Việt Nam</a> / <a title="Trưởng ban giám khảo: ''Kỳ Duyên xứng đáng trở thành Hoa hậu''" href="http://giaitri.vnexpress.net/tin-tuc/gioi-sao/trong-nuoc/truong-ban-giam-khao-ky-duyen-xung-dang-tro-thanh-hoa-hau-3117168;.html">Trưởng ban giám khảo: ''Kỳ Duyên xứng đáng trở thành Hoa hậu''</a></li>\n</ul>\n</div>\n<div class="fck_detail width_common">\n<p class="Normal">Nguyễn Cao Kỳ Duyên được xướng tên trong giây phút cuối cùng của đêm chung kết Hoa hậu Việt Nam 2014;, diễn ra tại sân khấu nhạc nước ngoài trời của Vinpearl Land, Phú Quốc, Kiên Giang (<a href="http://video.vnexpress.net/sao/hoa-hau-viet-nam-2014;-phan-cong-bo-ket-qua-3117190;.html" target="_blank">xem video</a>). Cô năm nay 18; tuổi, nằm trong nhóm thí sinh nhỏ tuổi nhất cuộc thi, và đang là sinh viên năm thứ nhất Đại học Ngoại Thương Hà Nội. Người đẹp cao 1,73; m, nặng 59; kg, số đo hình thể là 86;-63;-91;. Ngoài vẻ xinh xắn, đáng yêu, Kỳ Duyên còn là một cô gái tự tin, ham học hỏi và luôn thể hiện bản lĩnh trong phong cách giao tiếp, ứng xử.</p>\n<table class="tplCaption" border="0" cellspacing="0" cellpadding="3" align="center">\n<tbody>\n<tr>\n<td><img src="http://m.f9.img.vnexpress.net/2014;/12;/07;/dang-quang-ky-duyen-9212;-1417886120;.jpg" alt="dang-quang-ky-duyen-9212;-1417886120;.jpg" data-natural-="" data-width="500;" data-pwidth="470;.40625;" /></td>\n</tr>\n<tr>\n<td>\n<p class="Image">Nguyễn Cao Kỳ Duyên phút đăng quang.</p>\n</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Trước đêm chung kết, Nguyễn Cao Kỳ Duyên nằm trong số những cái tên được nhiều người <a href="http://giaitri.vnexpress.net/photo/trong-nuoc/10;-nguoi-dep-noi-bat-cua-cuoc-thi-hoa-hau-viet-nam-3116446;.html">dự đoán</a> cho ngôi vị hoa hậu. Người đẹp còn gây chú ý với câu chuyện <a href="http://giaitri.vnexpress.net/tin-tuc/gioi-sao/trong-nuoc/thi-sinh-hoa-hau-viet-nam-ke-chuyen-giam-hon-10;-kg-de-du-thi-3116184;.html">giảm cân hiệu quả</a>, khi từ 70; kg, trải qua quá trình luyện tập, ăn uống kiêng khem nghiêm ngặt, cô chỉ còn 59; kg trước khi đến với cuộc thi.</p>\n<p class="Normal">Trong phần thi ứng xử, Nguyễn Cao Kỳ Duyên nhận được câu hỏi từ giám khảo - biên đạo Trần Ly Ly: “Theo bạn điều gì làm người con gái Việt Nam không bị lẫn với những cô gái khác trên thế giới”. Kỳ Duyên trả lời: “Theo em, điều làm nên sự khác biệt ở phụ nữ Việt Nam đó là sự hy sinh. Từ nhỏ em đã được nghe kể về những người phụ nữ Việt Nam anh hùng, sẵn sàng hy sinh để chồng, con ra chiến trận và luôn dành hết tâm sức cho chồng con. Bên cạnh đó, phụ nữ Việt Nam còn sở hữu vẻ đằm thắm, dịu dàng và nét duyên ngầm” (<a href="http://video.vnexpress.net/giai-tri/hoa-hau-viet-nam-2014;-phan-thi-ung-xu-cua-nguyen-cao-ky-duyen-3117172;.html">xem video</a>).</p>\n<p class="Normal">Ngoài vương miện Hoa hậu Việt Nam 2014;, Nguyễn Cao Kỳ Duyên còn đoạt giải thưởng phụ<em> Người đẹp Biển</em>.</p>\n<table class="tplCaption" border="0" cellspacing="0" cellpadding="3" align="center">\n<tbody>\n<tr>\n<td><img src="http://m.f9.img.vnexpress.net/2014;/12;/07;/top3-6088;-1417886221;.jpg" alt="Top 3 Hoa hậu Việt Nam 2014;: Huyền My, Kỳ Duyên, Diễm Trang (từ trái qua)." data-natural-="" data-width="500;" data-pwidth="470;.40625;" /></td>\n</tr>\n<tr>\n<td>\n<p class="Image">Top 3 Hoa hậu Việt Nam 2014;: Huyền My, Kỳ Duyên, Diễm Trang (từ trái qua).</p>\n</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Nguyễn Trần Huyền My - thí sinh 19; tuổi đến từ Hà Nội - được trao ngôi Á hậu 1. Trước đó, cô luôn là thí sinh được kỳ vọng đăng quang nhất do sở hữu nét trong sáng, hiền hòa trên gương mặt. Trong phần thi ứng xử, Nguyễn Trần Huyền My được hỏi: "Trong vòng chung kết, em đã mặc chiếc áo cờ đỏ sao vàng cùng các thí sinh khác hát bài <em>Tổ Quốc gọi tên mình,</em> em nghĩ gì về khoảnh khắc đó?". Huyền My trả lời: “Đến bây giờ trong em vẫn nguyên cảm giác xúc động khi mặc chiếc áo cờ đỏ sao vàng, cất cao lời hát. Đó cũng chính là lời khẳng định của 38; thí sinh Hoa hậu Việt Nam 2014;, nguyện tiếp bước những người phụ nữ Việt Nam anh hùng, để có thể bảo vệ lãnh thổ, tấc đất thiêng liêng của Tổ quốc”.</p>\n<p class="Normal">Danh hiệu Á hậu 2 thuộc về Nguyễn Lâm Diễm Trang. Diễm Trang còn giành thêm giải thưởng <em>Người có gương mặt đẹp nhất</em>. Trước câu hỏi của nhà thơ Hữu Việt về xu hướng tôn thờ thần tượng thái quá của một bộ phận giới trẻ hiện nay, Diễm Trang trả lời: “Với em, là một trong những người trẻ trong bước đi đầu đời cần có định hướng. Thần tượng một ai đó sẽ có ích, vì nó là động lực cho bạn. Tuy nhiên chúng ta phải xác định rõ thần tượng họ vì điều gì, tài năng, trí tuệ hay chỉ là sự hào nhoáng bên ngoài. Tuổi trẻ cần có bản lĩnh để lựa chọn cho mình một thần tượng. Chọn thần tượng tốt và đúng, chúng ta sẽ thành công trong cuộc sống” (<a href="http://video.vnexpress.net/giai-tri/hoa-hau-viet-nam-2014;-phan-thi-ung-xu-cua-nguyen-lam-diem-trang-3117174;.html">xem video</a>).</p>\n<p class="Normal">Top 5 của cuộc thi còn có hai người đẹp Lã Thị Kiều Anh và <a href="http://giaitri.vnexpress.net/photo/trong-nuoc/nhung-ung-vien-hua-hen-gay-bat-ngo-trong-chung-ket-hoa-hau-3117018;.html">Nguyễn Thanh Tú</a>. Các thí sinh còn lại trong Top 10; gồm: Phạm Thị Hương, Nguyễn Huỳnh Trúc Mai, Trang Trần Diễm Quỳnh, Đỗ Thị Huệ, Nguyễn Thị Bảo Như (<a href="http://video.vnexpress.net/sao/hoa-hau-viet-nam-2014;-phan-cong-bo-ket-qua-top-10;-3117204;.html" target="_blank">xem video</a>). Nhiều người đẹp vào Top 10; nằm trong <a href="http://giaitri.vnexpress.net/photo/trong-nuoc/10;-nguoi-dep-noi-bat-cua-cuoc-thi-hoa-hau-viet-nam-3116446;.html">danh sách dự đoán</a> trước đó của <em>VnExpress</em>.</p>\n<table class="tplCaption" border="0" cellspacing="0" cellpadding="3" align="center">\n<tbody>\n<tr>\n<td><img src="http://m.f9.img.vnexpress.net/2014;/12;/06;/ao-dai2-7414;-1417876825;.jpg" alt="ao-dai2-7414;-1417876825;.jpg" data-natural-="" data-width="500;" data-pwidth="470;.40625;" /></td>\n</tr>\n<tr>\n<td>\n<p class="Image">Thí sinh Hoa hậu Việt Nam trình diễn áo dài.</p>\n</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Đêm chung kết Hoa hậu Việt Nam 2014; diễn ra trong gần ba tiếng đồng hồ. 38; thí sinh lọt vào vòng chung kết lần lượt trải qua các màn trình diễn áo dài (<a href="http://video.vnexpress.net/giai-tri/hoa-hau-viet-nam-2014;-phan-thi-ao-dai-3117165;.html">xem video</a>), áo tắm (<a href="http://video.vnexpress.net/sao/hoa-hau-viet-nam-2014;-phan-thi-trang-phuc-ao-tam-3117218;.html" target="_blank">xem video</a>) và váy dạ hội (<a href="http://video.vnexpress.net/sao/hoa-hau-viet-nam-2014;-phan-thi-trang-phuc-da-hoi-3117187;.html" target="_blank">xem video</a>). Sân khấu được thiết kế như một Phú Quốc thu nhỏ, ngập tràn hình ảnh biển đảo. Bộ áo tắm các người đẹp mặc để trình diễn cũng có màu xanh nước biển phù hợp với chủ đề của đêm thi. Trước đó, Ban tổ chức lo trời sẽ mưa nhưng đêm chung kết cuối cùng diễn ra trong tiết trời mát mẻ, dễ chịu.</p>\n<p class="Normal">Chương trình diễn ra với nhịp độ vừa phải, chừng mực, xen kẽ các phần thi là màn biểu diễn của các nghệ sĩ. Hồ Ngọc Hà được chọn mở màn chương trình. Nữ ca sĩ diện bộ đồ ôm thân lấp lánh trình diễn ca khúc <em>Dance All Night</em> của Dương Khắc Linh cùng vũ đoàn Hoàng Thông. Ca sĩ Hà Anh Tuấn xuất hiện trên sân khấu với ca khúc <em>Việt Nam quê hương tôi. </em>Tùng Dương vẫn "độc" và "quái" với <em>Con ốc </em>trong tiếng đàn của nghệ sĩ Nguyên Lê. Danh ca Hồng Nhung diện váy trắng với băng đô điệu đà thể hiện ca khúc <em>Bay đi cánh chim biển</em>.</p>\n<p class="Normal">Khách mời đặc biệt trình diễn trong đêm chung kết là ngôi sao ca nhạc người Mỹ Kelly Clarkson. Kelly nhận được sự hưởng ứng nhiệt tình của khán giả khi thể hiện ca khúc <em>Because Of You</em>. Gần cuối chương trình, cô trở lại với <em>Stronger</em><em>. </em>Kelly chia sẻ, mỗi phụ nữ muốn mạnh mẽ như tên ca khúc của cô thì cần nhất là sự tự tin. Nữ ca sĩ cũng dành tặng 38; thí sinh ca khúc <em>A Moment Like This </em>trước khi họ bước vào phần công bố kết quả.</p>\n<table class="tplCaption" border="0" cellspacing="0" cellpadding="3" align="center">\n<tbody>\n<tr>\n<td><img src="http://m.f9.img.vnexpress.net/2014;/12;/06;/kelly-JPG-8704;-1417876048;.jpg" alt="kelly-JPG-8704;-1417876048;.jpg" data-width="371;" data-pwidth="470;.40625;" /></td>\n</tr>\n<tr>\n<td>\n<p class="Image">Kelly Clarkson trên sân khấu Hoa hậu Việt Nam 2014;.</p>\n</td>\n</tr>\n</tbody>\n</table>\n</div>\n<p> </p>', '1928509200', 13123, '12312', 0, '1417942344', '1417943020', 1, 1),
(5, 0, 'fsad', 'fas4', 'media/1/project/c4966e0844bb4888162a8cfe5438bcb0.jpg', '312321312', '<div class="title_news">\n<div class="title_news">\n<h1>Nguyễn Cao Kỳ Duyên đăng quang Hoa hậu Việt Nam 2014;</h1>\n</div>\n<div class="short_intro txt_666;">Người đẹp 18; tuổi đến từ Nam Định giành vương miện trong đêm chung kết diễn ra tối 6/12; tại Phú Quốc, Kiên Giang. Danh hiệu Á hậu 1 thuộc về Nguyễn Trần Huyền My. Á hậu 2 là Nguyễn Lâm Diễm Trang.</div>\n<div class="relative_new">\n<ul class="list_news_dot_3x3_300;">\n<li><a title="10; người đẹp nổi bật của cuộc thi Hoa hậu Việt Nam" href="http://giaitri.vnexpress.net/photo/trong-nuoc/10;-nguoi-dep-noi-bat-cua-cuoc-thi-hoa-hau-viet-nam-3116446;.html">10; người đẹp nổi bật của cuộc thi Hoa hậu Việt Nam</a> / <a title="Trưởng ban giám khảo: ''Kỳ Duyên xứng đáng trở thành Hoa hậu''" href="http://giaitri.vnexpress.net/tin-tuc/gioi-sao/trong-nuoc/truong-ban-giam-khao-ky-duyen-xung-dang-tro-thanh-hoa-hau-3117168;.html">Trưởng ban giám khảo: ''Kỳ Duyên xứng đáng trở thành Hoa hậu''</a></li>\n</ul>\n</div>\n<div class="fck_detail width_common">\n<p class="Normal">Nguyễn Cao Kỳ Duyên được xướng tên trong giây phút cuối cùng của đêm chung kết Hoa hậu Việt Nam 2014;, diễn ra tại sân khấu nhạc nước ngoài trời của Vinpearl Land, Phú Quốc, Kiên Giang (<a href="http://video.vnexpress.net/sao/hoa-hau-viet-nam-2014;-phan-cong-bo-ket-qua-3117190;.html" target="_blank">xem video</a>). Cô năm nay 18; tuổi, nằm trong nhóm thí sinh nhỏ tuổi nhất cuộc thi, và đang là sinh viên năm thứ nhất Đại học Ngoại Thương Hà Nội. Người đẹp cao 1,73; m, nặng 59; kg, số đo hình thể là 86;-63;-91;. Ngoài vẻ xinh xắn, đáng yêu, Kỳ Duyên còn là một cô gái tự tin, ham học hỏi và luôn thể hiện bản lĩnh trong phong cách giao tiếp, ứng xử.</p>\n<table class="tplCaption" border="0" cellspacing="0" cellpadding="3" align="center">\n<tbody>\n<tr>\n<td><img src="http://m.f9.img.vnexpress.net/2014;/12;/07;/dang-quang-ky-duyen-9212;-1417886120;.jpg" alt="dang-quang-ky-duyen-9212;-1417886120;.jpg" data-natural-="" data-width="500;" data-pwidth="470;.40625;" /></td>\n</tr>\n<tr>\n<td>\n<p class="Image">Nguyễn Cao Kỳ Duyên phút đăng quang.</p>\n</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Trước đêm chung kết, Nguyễn Cao Kỳ Duyên nằm trong số những cái tên được nhiều người <a href="http://giaitri.vnexpress.net/photo/trong-nuoc/10;-nguoi-dep-noi-bat-cua-cuoc-thi-hoa-hau-viet-nam-3116446;.html">dự đoán</a> cho ngôi vị hoa hậu. Người đẹp còn gây chú ý với câu chuyện <a href="http://giaitri.vnexpress.net/tin-tuc/gioi-sao/trong-nuoc/thi-sinh-hoa-hau-viet-nam-ke-chuyen-giam-hon-10;-kg-de-du-thi-3116184;.html">giảm cân hiệu quả</a>, khi từ 70; kg, trải qua quá trình luyện tập, ăn uống kiêng khem nghiêm ngặt, cô chỉ còn 59; kg trước khi đến với cuộc thi.</p>\n<p class="Normal">Trong phần thi ứng xử, Nguyễn Cao Kỳ Duyên nhận được câu hỏi từ giám khảo - biên đạo Trần Ly Ly: “Theo bạn điều gì làm người con gái Việt Nam không bị lẫn với những cô gái khác trên thế giới”. Kỳ Duyên trả lời: “Theo em, điều làm nên sự khác biệt ở phụ nữ Việt Nam đó là sự hy sinh. Từ nhỏ em đã được nghe kể về những người phụ nữ Việt Nam anh hùng, sẵn sàng hy sinh để chồng, con ra chiến trận và luôn dành hết tâm sức cho chồng con. Bên cạnh đó, phụ nữ Việt Nam còn sở hữu vẻ đằm thắm, dịu dàng và nét duyên ngầm” (<a href="http://video.vnexpress.net/giai-tri/hoa-hau-viet-nam-2014;-phan-thi-ung-xu-cua-nguyen-cao-ky-duyen-3117172;.html">xem video</a>).</p>\n<p class="Normal">Ngoài vương miện Hoa hậu Việt Nam 2014;, Nguyễn Cao Kỳ Duyên còn đoạt giải thưởng phụ<em> Người đẹp Biển</em>.</p>\n<table class="tplCaption" border="0" cellspacing="0" cellpadding="3" align="center">\n<tbody>\n<tr>\n<td><img src="http://m.f9.img.vnexpress.net/2014;/12;/07;/top3-6088;-1417886221;.jpg" alt="Top 3 Hoa hậu Việt Nam 2014;: Huyền My, Kỳ Duyên, Diễm Trang (từ trái qua)." data-natural-="" data-width="500;" data-pwidth="470;.40625;" /></td>\n</tr>\n<tr>\n<td>\n<p class="Image">Top 3 Hoa hậu Việt Nam 2014;: Huyền My, Kỳ Duyên, Diễm Trang (từ trái qua).</p>\n</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Nguyễn Trần Huyền My - thí sinh 19; tuổi đến từ Hà Nội - được trao ngôi Á hậu 1. Trước đó, cô luôn là thí sinh được kỳ vọng đăng quang nhất do sở hữu nét trong sáng, hiền hòa trên gương mặt. Trong phần thi ứng xử, Nguyễn Trần Huyền My được hỏi: "Trong vòng chung kết, em đã mặc chiếc áo cờ đỏ sao vàng cùng các thí sinh khác hát bài <em>Tổ Quốc gọi tên mình,</em> em nghĩ gì về khoảnh khắc đó?". Huyền My trả lời: “Đến bây giờ trong em vẫn nguyên cảm giác xúc động khi mặc chiếc áo cờ đỏ sao vàng, cất cao lời hát. Đó cũng chính là lời khẳng định của 38; thí sinh Hoa hậu Việt Nam 2014;, nguyện tiếp bước những người phụ nữ Việt Nam anh hùng, để có thể bảo vệ lãnh thổ, tấc đất thiêng liêng của Tổ quốc”.</p>\n<p class="Normal">Danh hiệu Á hậu 2 thuộc về Nguyễn Lâm Diễm Trang. Diễm Trang còn giành thêm giải thưởng <em>Người có gương mặt đẹp nhất</em>. Trước câu hỏi của nhà thơ Hữu Việt về xu hướng tôn thờ thần tượng thái quá của một bộ phận giới trẻ hiện nay, Diễm Trang trả lời: “Với em, là một trong những người trẻ trong bước đi đầu đời cần có định hướng. Thần tượng một ai đó sẽ có ích, vì nó là động lực cho bạn. Tuy nhiên chúng ta phải xác định rõ thần tượng họ vì điều gì, tài năng, trí tuệ hay chỉ là sự hào nhoáng bên ngoài. Tuổi trẻ cần có bản lĩnh để lựa chọn cho mình một thần tượng. Chọn thần tượng tốt và đúng, chúng ta sẽ thành công trong cuộc sống” (<a href="http://video.vnexpress.net/giai-tri/hoa-hau-viet-nam-2014;-phan-thi-ung-xu-cua-nguyen-lam-diem-trang-3117174;.html">xem video</a>).</p>\n<p class="Normal">Top 5 của cuộc thi còn có hai người đẹp Lã Thị Kiều Anh và <a href="http://giaitri.vnexpress.net/photo/trong-nuoc/nhung-ung-vien-hua-hen-gay-bat-ngo-trong-chung-ket-hoa-hau-3117018;.html">Nguyễn Thanh Tú</a>. Các thí sinh còn lại trong Top 10; gồm: Phạm Thị Hương, Nguyễn Huỳnh Trúc Mai, Trang Trần Diễm Quỳnh, Đỗ Thị Huệ, Nguyễn Thị Bảo Như (<a href="http://video.vnexpress.net/sao/hoa-hau-viet-nam-2014;-phan-cong-bo-ket-qua-top-10;-3117204;.html" target="_blank">xem video</a>). Nhiều người đẹp vào Top 10; nằm trong <a href="http://giaitri.vnexpress.net/photo/trong-nuoc/10;-nguoi-dep-noi-bat-cua-cuoc-thi-hoa-hau-viet-nam-3116446;.html">danh sách dự đoán</a> trước đó của <em>VnExpress</em>.</p>\n<table class="tplCaption" border="0" cellspacing="0" cellpadding="3" align="center">\n<tbody>\n<tr>\n<td><img src="http://m.f9.img.vnexpress.net/2014;/12;/06;/ao-dai2-7414;-1417876825;.jpg" alt="ao-dai2-7414;-1417876825;.jpg" data-natural-="" data-width="500;" data-pwidth="470;.40625;" /></td>\n</tr>\n<tr>\n<td>\n<p class="Image">Thí sinh Hoa hậu Việt Nam trình diễn áo dài.</p>\n</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Đêm chung kết Hoa hậu Việt Nam 2014; diễn ra trong gần ba tiếng đồng hồ. 38; thí sinh lọt vào vòng chung kết lần lượt trải qua các màn trình diễn áo dài (<a href="http://video.vnexpress.net/giai-tri/hoa-hau-viet-nam-2014;-phan-thi-ao-dai-3117165;.html">xem video</a>), áo tắm (<a href="http://video.vnexpress.net/sao/hoa-hau-viet-nam-2014;-phan-thi-trang-phuc-ao-tam-3117218;.html" target="_blank">xem video</a>) và váy dạ hội (<a href="http://video.vnexpress.net/sao/hoa-hau-viet-nam-2014;-phan-thi-trang-phuc-da-hoi-3117187;.html" target="_blank">xem video</a>). Sân khấu được thiết kế như một Phú Quốc thu nhỏ, ngập tràn hình ảnh biển đảo. Bộ áo tắm các người đẹp mặc để trình diễn cũng có màu xanh nước biển phù hợp với chủ đề của đêm thi. Trước đó, Ban tổ chức lo trời sẽ mưa nhưng đêm chung kết cuối cùng diễn ra trong tiết trời mát mẻ, dễ chịu.</p>\n<p class="Normal">Chương trình diễn ra với nhịp độ vừa phải, chừng mực, xen kẽ các phần thi là màn biểu diễn của các nghệ sĩ. Hồ Ngọc Hà được chọn mở màn chương trình. Nữ ca sĩ diện bộ đồ ôm thân lấp lánh trình diễn ca khúc <em>Dance All Night</em> của Dương Khắc Linh cùng vũ đoàn Hoàng Thông. Ca sĩ Hà Anh Tuấn xuất hiện trên sân khấu với ca khúc <em>Việt Nam quê hương tôi. </em>Tùng Dương vẫn "độc" và "quái" với <em>Con ốc </em>trong tiếng đàn của nghệ sĩ Nguyên Lê. Danh ca Hồng Nhung diện váy trắng với băng đô điệu đà thể hiện ca khúc <em>Bay đi cánh chim biển</em>.</p>\n<p class="Normal">Khách mời đặc biệt trình diễn trong đêm chung kết là ngôi sao ca nhạc người Mỹ Kelly Clarkson. Kelly nhận được sự hưởng ứng nhiệt tình của khán giả khi thể hiện ca khúc <em>Because Of You</em>. Gần cuối chương trình, cô trở lại với <em>Stronger</em><em>. </em>Kelly chia sẻ, mỗi phụ nữ muốn mạnh mẽ như tên ca khúc của cô thì cần nhất là sự tự tin. Nữ ca sĩ cũng dành tặng 38; thí sinh ca khúc <em>A Moment Like This </em>trước khi họ bước vào phần công bố kết quả.</p>\n<table class="tplCaption" border="0" cellspacing="0" cellpadding="3" align="center">\n<tbody>\n<tr>\n<td><img src="http://m.f9.img.vnexpress.net/2014;/12;/06;/kelly-JPG-8704;-1417876048;.jpg" alt="kelly-JPG-8704;-1417876048;.jpg" data-width="371;" data-pwidth="470;.40625;" /></td>\n</tr>\n<tr>\n<td>\n<p class="Image">Kelly Clarkson trên sân khấu Hoa hậu Việt Nam 2014;.</p>\n</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Dẫn chương trình đêm chung kết Hoa hậu Việt Nam 2014; là Jennifer Phạm và MC Khắc Nguyện. Ban giám khảo Hoa hậu Việt Nam 2014; gồm: Tiến sĩ, nhà thơ Lê Cảnh Nhạc, Hoa hậu Việt Nam 2010; Đặng Thị Ngọc Hân, biên đạo múa Trần Ly Ly, nhà nhân trắc học Lê Diệp Linh, nhà báo - nhà thơ Hữu Việt.</p>\n<p class="Normal">Mở đầu cuộc thi, ông Lê Xuân Sơn - trưởng ban tổ chức cuộc thi - chia sẻ: "Vì sao hàng tỷ người trên Trái đất luôn dõi theo các cuộc thi Hoa hậu? Có lẽ bởi con người chúng ta có một đặc tính tốt đẹp là cảm nhận, yêu và bị hấp dẫn bởi cái đẹp. Trong khi đó, bản thân cái đẹp luôn mới, không bao giờ lặp lại và có mãnh lực thu hút nhân loại". Theo ông Sơn, vòng chung kết cuộc thi năm nay đến với Phú Quốc với mục đích đóng góp, thúc đẩy phần nào sự phát triển của mảnh đất tươi đẹp, giàu tiềm năng này.</p>\n<p class="Normal">Có mặt trên hàng ghế khách mời, Hoa hậu Việt Nam 2006; - Mai Phương Thúy - chia sẻ: "Mọi người thường quan niệm cô gái đẹp nhất sẽ được chọn thành hoa hậu. Thúy cho rằng người được chọn thành hoa hậu sẽ trở thành người đẹp nhất. Bởi chủ nhân của danh hiệu đã được lựa chọn từ khắp miền đất nước sẽ phải là người hội đủ các yếu tố chân - thiện - mỹ để đại diện cho nhan sắc quốc gia".</p>\n<p class="Normal">Dù 20;h chương trình mới bắt đầu, từ 15;h, 38; thí sinh bắt đầu được trang điểm, làm tóc và chuẩn bị trang phục để bước vào đêm thi. Trước đó từ 14;h chiều, lực lượng công an và dân phòng của tỉnh Kiên Giang được điều động về khu vực sân khấu để giữ trật tự cho chương trình. Vì số lượng ghế ngồi tại sân khấu chỉ giới hạn khoảng hơn 2.000; chỗ ngồi, nên có người sẵn sàng bỏ số tiền cao để mua lại cặp vé xem đêm thi hoa hậu. Vé của chương trình thuộc diện vé tặng từ ban tổ chức chứ không bán ra thị trường.</p>\n<div>\n<div class="embed-container">&lt;iframe src="http://vnexpress.net/parser.php?id=29811;&t=2&ft=video&si=1002691;&ap=1&ishome=0" width="480;" height="270;" frameborder="0" allowfullscreen="allowfullscreen"&gt;&lt;/iframe></div>\n</div>\n<table border="1" cellspacing="0" cellpadding="1">\n<tbody>\n<tr>\n<td>\n<p class="Normal"><strong>* Các giải thưởng phụ của cuộc thi Hoa hậu Việt Nam 2014; (<a href="http://video.vnexpress.net/sao/hoa-hau-viet-nam-2014;-phan-cong-bo-ket-qua-giai-thuong-phu-3117211;.html" target="_blank">xem video</a>):</strong></p>\n<p class="Normal">Người đẹp Biển: Nguyễn Cao Kỳ Duyên (SBD 283;)<br /><br />Người đẹp Tài năng: Lã Thị Kiều Anh (SBD 099;)<br /><br />Người có làn da đẹp nhất: Nguyễn Thanh Tú (SBD 268;)<br /><br />Người đẹp Áo dài: Nguyễn Huỳnh Trúc Mai (SBD 491;)<br /><br />Người có trang phục dạ hội đẹp nhất: Nguyễn Trần Huyền My (SBD 289;)<br /><br />Giải thưởng do khán giả bình chọn: Đỗ Thị Huệ (SBD 532;)<br /><br />Người có mái tóc đẹp nhất: Nguyễn Thị Hà (SBD 316;)<br /><br />Người có gương mặt đẹp nhất: Nguyễn Lâm Diễm Trang (SBD 858;)</p>\n</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal"><strong>Hoàng Anh - Chi Mai</strong><br />Ảnh:<em> Maison de Bil, Lý Võ Phú Hưng</em></p>\n</div>\n</div>', '1928509200', 13123, '12312', 0, '1417942373', '', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `thnd_project_backers`
--

CREATE TABLE IF NOT EXISTS `thnd_project_backers` (
  `backerid` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  `backername` varchar(30) NOT NULL,
  `backertime` text NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `image` text,
  `status` int(11) NOT NULL,
  `created_date` text NOT NULL,
  `modified_date` text NOT NULL,
  `created_user` int(11) DEFAULT NULL,
  `modified_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`backerid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `thnd_project_backers`
--


-- --------------------------------------------------------

--
-- Table structure for table `thnd_project_category`
--

CREATE TABLE IF NOT EXISTS `thnd_project_category` (
  `categoryid` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` int(11) NOT NULL,
  `categoryname` varchar(30) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` text NOT NULL,
  `modified_date` text NOT NULL,
  `created_user` int(11) DEFAULT NULL,
  `modified_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`categoryid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `thnd_project_category`
--


-- --------------------------------------------------------

--
-- Table structure for table `thnd_user`
--

CREATE TABLE IF NOT EXISTS `thnd_user` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` text NOT NULL,
  `usergroup` int(11) NOT NULL,
  `email` text NOT NULL,
  `facebook` text,
  `firstname` text,
  `lastname` text,
  `avatarpath` text,
  `status` int(1) NOT NULL,
  `created_date` text NOT NULL,
  `modified_date` text NOT NULL,
  `created_user` int(11) DEFAULT NULL,
  `modified_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `thnd_user`
--

INSERT INTO `thnd_user` (`userid`, `username`, `password`, `usergroup`, `email`, `facebook`, `firstname`, `lastname`, `avatarpath`, `status`, `created_date`, `modified_date`, `created_user`, `modified_user`) VALUES
(1, 'vv0lll', 'e10adc3949ba59abbe56e057f20f883e', 1, 'dancer.thanh@gmail.com', 'https://www.facebook.com/dancer.thanh', 'Công Thành', 'Vũ', 'https://scontent-b-hkg.xx.fbcdn.net/hphotos-xfp1/v/t1.0-9/10409650_796545310403731_2069750072816195716_n.jpg?oh=39ff9bf90be8e0180e45a92546e8d0a5&oe=550DE39D', 1, '1414002306', '1414002306', 1, 1),
(7, 'thanhvc', 'e10adc3949ba59abbe56e057f20f883e', 4, 'vucongthanh_9x@yahoo.com', '', '', '', '', 0, '', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `thnd_usergroup`
--

CREATE TABLE IF NOT EXISTS `thnd_usergroup` (
  `usergroupid` int(11) NOT NULL AUTO_INCREMENT,
  `usergroupname` varchar(30) NOT NULL,
  `description` text,
  `status` int(11) NOT NULL,
  `created_date` text NOT NULL,
  `modified_date` text,
  `created_user` int(11) NOT NULL,
  `modified_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`usergroupid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `thnd_usergroup`
--

INSERT INTO `thnd_usergroup` (`usergroupid`, `usergroupname`, `description`, `status`, `created_date`, `modified_date`, `created_user`, `modified_user`) VALUES
(1, 'Administrator', NULL, 1, '1414607065', NULL, 1, NULL),
(4, 'Content', '', 1, '1414653785', '1417653782', 1, 1),
(9, 'Sponsor', 'The sponsors of website', 0, '1414655876', '1417653787', 1, 1);
